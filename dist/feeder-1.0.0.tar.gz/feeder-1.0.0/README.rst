Quick start
-----------

 Use it like this:

    python -m feeder

tips:

    This module can get news from the rss url you give. Wether it is full content

    or not depends on your rss, which may get a better solution in later editons.